
import React, { useState, useEffect } from 'react';
import { MY_VIDEOS } from '../constants';
import { analyzeOutlier } from '../services/geminiService';
import { 
  Sparkles, 
  BrainCircuit, 
  ListChecks, 
  TrendingUp, 
  Zap, 
  Target,
  BarChart2,
  Share2
} from 'lucide-react';

const OutlierDeepDive: React.FC = () => {
  const outliers = MY_VIDEOS.filter(v => v.isOutlier);
  const [selectedVideo, setSelectedVideo] = useState(outliers[0]);
  const [analysis, setAnalysis] = useState<string>('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchAnalysis = async () => {
      setLoading(true);
      try {
        const result = await analyzeOutlier(selectedVideo.title, selectedVideo.metrics);
        setAnalysis(result || 'No analysis available.');
      } catch (err) {
        setAnalysis('### ⚠️ Analysis Failed\nAI analysis failed. Please check your API key or network connection.');
      } finally {
        setLoading(false);
      }
    };
    fetchAnalysis();
  }, [selectedVideo]);

  // Simple markdown-to-html helper for the specific headers
  const renderAnalysis = (text: string) => {
    return text.split('\n').map((line, i) => {
      if (line.startsWith('### ')) {
        return <h3 key={i} className="text-lg font-bold text-slate-900 mt-6 mb-3 flex items-center gap-2 border-b border-slate-100 pb-2">{line.replace('### ', '')}</h3>;
      }
      if (line.startsWith('- ') || line.startsWith('* ')) {
        return <li key={i} className="ml-4 mb-2 text-slate-600 list-disc">{line.substring(2)}</li>;
      }
      return <p key={i} className="mb-2 text-slate-600 leading-relaxed">{line}</p>;
    });
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="bg-indigo-100 text-indigo-700 text-[10px] font-black px-2 py-0.5 rounded uppercase tracking-tighter">Strategic Analysis</span>
          </div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight">Outlier Intelligence</h1>
          <p className="text-slate-500 font-medium">Deconstructing your highest performing content assets.</p>
        </div>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-600 hover:bg-slate-50 transition-all">
            <Share2 size={16} />
            Export Report
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Sidebar: Navigation of Outliers */}
        <div className="lg:col-span-3 space-y-4">
          <div className="bg-slate-50/50 p-2 rounded-2xl border border-slate-200/60">
            <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-3 px-3 pt-2">Performance Anomalies</h3>
            <div className="space-y-2">
              {outliers.map(video => (
                <button
                  key={video.id}
                  onClick={() => setSelectedVideo(video)}
                  className={`w-full text-left p-3 rounded-xl transition-all group relative overflow-hidden ${
                    selectedVideo.id === video.id 
                      ? 'bg-white shadow-xl shadow-indigo-100/50 ring-1 ring-indigo-500/20' 
                      : 'hover:bg-white hover:shadow-md'
                  }`}
                >
                  <div className="flex gap-3">
                    <div className="relative shrink-0">
                      <img src={video.thumbnailUrl} className="w-20 h-12 object-cover rounded-lg" alt="" />
                      {selectedVideo.id === video.id && (
                        <div className="absolute inset-0 bg-indigo-600/10 rounded-lg"></div>
                      )}
                    </div>
                    <div className="min-w-0">
                      <div className={`text-xs font-bold leading-tight line-clamp-2 transition-colors ${selectedVideo.id === video.id ? 'text-indigo-600' : 'text-slate-800'}`}>
                        {video.title}
                      </div>
                      <div className="flex items-center gap-1.5 mt-1.5">
                        <TrendingUp size={10} className="text-emerald-500" />
                        <span className="text-[10px] font-black text-emerald-600">+{video.outlierDelta}σ</span>
                      </div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div className="bg-gradient-to-br from-slate-900 to-slate-800 p-6 rounded-2xl text-white relative overflow-hidden shadow-xl">
             <div className="relative z-10">
                <div className="w-10 h-10 bg-indigo-500/20 rounded-lg flex items-center justify-center mb-4 border border-white/10">
                  <Zap size={20} className="text-indigo-400" />
                </div>
                <h4 className="font-bold text-sm mb-1">Growth Prediction</h4>
                <p className="text-slate-400 text-xs leading-relaxed">Videos like this usually see a <span className="text-indigo-400 font-bold">2.4x</span> lift in organic search traffic within 90 days.</p>
             </div>
             <BarChart2 className="absolute -right-4 -bottom-4 opacity-10" size={100} />
          </div>
        </div>

        {/* Main Analysis Area */}
        <div className="lg:col-span-9 space-y-8">
          {/* Header Card */}
          <div className="bg-white p-1 rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="flex flex-col md:flex-row">
              <div className="w-full md:w-1/2 p-1">
                <div className="relative group">
                  <img src={selectedVideo.thumbnailUrl} className="w-full aspect-video object-cover rounded-[1.25rem] shadow-2xl transition-transform duration-700 group-hover:scale-[1.02]" alt="" />
                  <div className="absolute top-4 left-4 flex gap-2">
                    <div className="bg-black/60 backdrop-blur-md text-white text-[10px] font-black px-2.5 py-1 rounded-full border border-white/20">
                      PREVIEW
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex-1 p-8 flex flex-col justify-center">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-2 h-2 rounded-full bg-indigo-500"></div>
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Outlier Data Point</span>
                </div>
                <h2 className="text-2xl font-black text-slate-900 mb-6 leading-tight">{selectedVideo.title}</h2>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 hover:bg-slate-100/50 transition-colors">
                    <div className="flex items-center gap-2 text-slate-500 mb-1">
                      <Target size={14} />
                      <span className="text-[10px] font-bold uppercase tracking-wider">CTR Efficiency</span>
                    </div>
                    <div className="text-2xl font-black text-emerald-600">{selectedVideo.metrics.ctr}%</div>
                    <div className="text-[10px] text-slate-400 font-medium">{(selectedVideo.metrics.ctr * 1.4).toFixed(1)}% Benchmark</div>
                  </div>
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 hover:bg-slate-100/50 transition-colors">
                    <div className="flex items-center gap-2 text-slate-500 mb-1">
                      <Zap size={14} />
                      <span className="text-[10px] font-bold uppercase tracking-wider">Retention</span>
                    </div>
                    <div className="text-2xl font-black text-indigo-600">62%</div>
                    <div className="text-[10px] text-slate-400 font-medium">Avg. 4:22m View Time</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* AI Intelligence Report Section */}
          <div className="relative">
            <div className="absolute -inset-1 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-[2rem] opacity-20 blur-xl"></div>
            <div className="relative bg-white p-10 rounded-[2rem] border border-slate-200 shadow-xl overflow-hidden min-h-[400px]">
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-indigo-50 rounded-2xl flex items-center justify-center text-indigo-600 border border-indigo-100">
                    <Sparkles size={24} />
                  </div>
                  <div>
                    <h3 className="font-black text-slate-900 text-xl tracking-tight">Intelligence Report</h3>
                    <p className="text-slate-400 text-xs font-bold uppercase tracking-widest">Generated by Gemini Pro</p>
                  </div>
                </div>
                {loading && (
                  <div className="flex items-center gap-2 px-3 py-1 bg-slate-50 rounded-full border border-slate-100 animate-pulse">
                    <div className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-bounce"></div>
                    <span className="text-[10px] font-black text-slate-500">THINKING</span>
                  </div>
                )}
              </div>
              
              {loading ? (
                <div className="space-y-6">
                  <div className="space-y-3">
                    <div className="h-6 bg-slate-100 rounded-lg w-1/4"></div>
                    <div className="h-4 bg-slate-50 rounded-lg w-full"></div>
                    <div className="h-4 bg-slate-50 rounded-lg w-5/6"></div>
                  </div>
                  <div className="space-y-3 pt-6">
                    <div className="h-6 bg-slate-100 rounded-lg w-1/3"></div>
                    <div className="h-4 bg-slate-50 rounded-lg w-full"></div>
                    <div className="h-4 bg-slate-50 rounded-lg w-4/6"></div>
                  </div>
                </div>
              ) : (
                <div className="max-w-none">
                  <div className="bg-indigo-50/30 p-6 rounded-2xl border border-indigo-100/50 mb-8 italic text-indigo-900/70 font-medium leading-relaxed">
                    This video successfully bridged the gap between your core automation audience and the broader "SaaS Builders" community. The outlier effect is primarily driven by high search volume for your chosen keyword paired with a high-stakes title structure.
                  </div>
                  <div className="prose prose-slate">
                    {renderAnalysis(analysis)}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Action Strategy Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-12">
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:border-indigo-200 transition-all">
              <h3 className="font-black text-slate-900 mb-4 flex items-center gap-2">
                <BrainCircuit size={18} className="text-indigo-500" />
                Structural DNA
              </h3>
              <div className="space-y-4">
                {[
                  { label: 'Thumbnail Style', val: 'Minimalist / Action' },
                  { label: 'Title Hook', val: 'Scarcity + Results' },
                  { label: 'Traffic Source', val: '72% Browse' },
                ].map((item, idx) => (
                  <div key={idx} className="flex justify-between items-center py-2 border-b border-slate-50 last:border-0">
                    <span className="text-xs font-medium text-slate-500">{item.label}</span>
                    <span className="text-xs font-black text-slate-800">{item.val}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:border-emerald-200 transition-all">
              <h3 className="font-black text-slate-900 mb-4 flex items-center gap-2">
                <ListChecks size={18} className="text-emerald-500" />
                Execution Plan
              </h3>
              <div className="space-y-3">
                {[
                  'Mirror title structure in next 3 videos',
                  'Test similar high-contrast blue/black color palette',
                  'Retarget this audience in community posts'
                ].map((item, idx) => (
                  <div key={idx} className="flex items-center gap-3 group">
                    <div className="w-6 h-6 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center text-[10px] font-black group-hover:bg-emerald-500 group-hover:text-white transition-all">
                      {idx + 1}
                    </div>
                    <span className="text-xs font-medium text-slate-600 group-hover:text-slate-900 transition-colors">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OutlierDeepDive;


import React from 'react';
import { 
  Settings, 
  Youtube, 
  Key, 
  Target, 
  Tag, 
  Save,
  ShieldCheck,
  BellRing
} from 'lucide-react';

const SettingsView: React.FC = () => {
  return (
    <div className="max-w-4xl space-y-8 animate-in fade-in duration-500 pb-20">
      <div>
        <h1 className="text-3xl font-black text-slate-900 tracking-tight">Settings</h1>
        <p className="text-slate-500 font-medium">Configure your channel intelligence and business alignment.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="col-span-2 space-y-6">
          {/* Channel Config */}
          <section className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm space-y-6">
            <div className="flex items-center gap-3 pb-4 border-b border-slate-50">
              <div className="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center text-indigo-600">
                <Youtube size={20} />
              </div>
              <div>
                <h3 className="font-bold text-slate-800">Channel Integration</h3>
                <p className="text-xs text-slate-400">Manage your connected YouTube Analytics data.</p>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Channel ID</label>
                <div className="flex gap-2">
                  <input 
                    type="text" 
                    readOnly 
                    value="UC_x5XG1OV2P6uZZ5FSM9Ttw" 
                    className="flex-1 px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono text-slate-500"
                  />
                  <button className="px-4 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-50">Reconnect</button>
                </div>
              </div>
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Sync Frequency</label>
                <select className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-800">
                  <option>Every 6 Hours (Daily SOP)</option>
                  <option>Real-time (High Priority)</option>
                  <option>Daily at 6AM</option>
                </select>
              </div>
            </div>
          </section>

          {/* AI Intelligence Config */}
          <section className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm space-y-6">
            <div className="flex items-center gap-3 pb-4 border-b border-slate-50">
              <div className="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center text-indigo-600">
                <ShieldCheck size={20} />
              </div>
              <div>
                <h3 className="font-bold text-slate-800">AI Logic & Thresholds</h3>
                <p className="text-xs text-slate-400">Customize how anomalies and opportunities are flagged.</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Outlier σ-Threshold</label>
                <input type="range" className="w-full accent-indigo-600" min="1" max="4" step="0.5" defaultValue="2.5" />
                <div className="flex justify-between text-[10px] font-bold text-slate-400 mt-1">
                  <span>1.0σ (Sensitive)</span>
                  <span>2.5σ (Default)</span>
                </div>
              </div>
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Confidence Level</label>
                <select className="w-full px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm font-bold">
                  <option>High (95%)</option>
                  <option>Balanced (80%)</option>
                  <option>Experimental (50%)</option>
                </select>
              </div>
            </div>
          </section>

          {/* Brand Pillars */}
          <section className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm space-y-6">
            <div className="flex items-center gap-3 pb-4 border-b border-slate-50">
              <div className="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center text-indigo-600">
                <Tag size={20} />
              </div>
              <div>
                <h3 className="font-bold text-slate-800">Content Pillars</h3>
                <p className="text-xs text-slate-400">Used to calculate Brand Alignment scores.</p>
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              {['AI Automation', 'No-Code SaaS', 'Workflow Engineering', 'B2B Productivity'].map(pillar => (
                <div key={pillar} className="px-3 py-1.5 bg-indigo-50 text-indigo-600 rounded-lg text-xs font-black border border-indigo-100 flex items-center gap-2">
                  {pillar}
                  <button className="hover:text-indigo-900">×</button>
                </div>
              ))}
              <button className="px-3 py-1.5 border border-dashed border-slate-200 rounded-lg text-xs font-bold text-slate-400 hover:border-indigo-400 hover:text-indigo-600 transition-all">+ Add Pillar</button>
            </div>
          </section>
        </div>

        {/* Sidebar Settings */}
        <div className="space-y-6">
          <div className="bg-indigo-900 p-8 rounded-[2.5rem] text-white shadow-xl relative overflow-hidden">
            <div className="relative z-10 space-y-6">
              <h4 className="font-black text-xl leading-tight">Apply Strategy Configuration</h4>
              <p className="text-indigo-200 text-sm leading-relaxed">Updating these settings will re-calculate your Opportunity Scores and Outlier Reports based on new benchmarks.</p>
              <button className="w-full py-4 bg-white text-indigo-900 rounded-2xl font-black flex items-center justify-center gap-2 hover:bg-indigo-50 transition-all active:scale-[0.98] shadow-2xl shadow-black/20">
                <Save size={20} />
                Save Changes
              </button>
            </div>
            <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-indigo-500 rounded-full opacity-20 blur-3xl"></div>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
            <h4 className="font-bold text-slate-800 text-sm flex items-center gap-2">
              <BellRing size={18} className="text-slate-400" />
              Notifications
            </h4>
            <div className="space-y-3">
              {[
                { label: 'Outlier Alerts', active: true },
                { label: 'Weekly Reports', active: true },
                { label: 'Trend Spikes', active: false },
              ].map(n => (
                <label key={n.label} className="flex items-center justify-between cursor-pointer group">
                  <span className="text-xs font-bold text-slate-600 group-hover:text-slate-900">{n.label}</span>
                  <div className={`w-10 h-5 rounded-full transition-colors relative ${n.active ? 'bg-indigo-600' : 'bg-slate-200'}`}>
                    <div className={`absolute top-1 w-3 h-3 bg-white rounded-full transition-all ${n.active ? 'left-6' : 'left-1'}`}></div>
                  </div>
                </label>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsView;

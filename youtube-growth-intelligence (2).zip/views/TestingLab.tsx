
import React from 'react';
import { Microscope, Play, History, CheckCircle2, XCircle } from 'lucide-react';

const TestingLab: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Testing Lab</h1>
          <p className="text-slate-500">Thumbnail & Title A/B experimentation center.</p>
        </div>
        <button className="px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium flex items-center gap-2 hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-200">
          <Play size={18} />
          New Experiment
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white p-6 rounded-xl border border-slate-200">
            <h3 className="font-bold text-slate-800 mb-6 flex items-center gap-2">
              <Microscope size={18} className="text-indigo-600" />
              Active Tests
            </h3>
            <div className="space-y-6">
              <div className="border border-slate-100 rounded-xl p-6 bg-slate-50/50">
                <div className="flex justify-between items-start mb-6">
                  <div>
                    <h4 className="font-bold text-slate-800">Thumbnail Variant Test</h4>
                    <p className="text-xs text-slate-500">Video: "Scaling an Agency to $10k/mo"</p>
                  </div>
                  <span className="bg-indigo-100 text-indigo-700 text-[10px] font-bold px-2 py-1 rounded uppercase">Live (48h)</span>
                </div>
                
                <div className="grid grid-cols-2 gap-8">
                  <div className="space-y-3">
                    <div className="relative">
                      <img src="https://picsum.photos/seed/test1/640/360" className="w-full aspect-video object-cover rounded-lg border-2 border-slate-200" alt="" />
                      <div className="absolute top-2 left-2 bg-white text-slate-800 text-[10px] font-bold px-2 py-1 rounded shadow-sm">Variant A (Control)</div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-bold text-slate-500 uppercase">CTR</span>
                      <span className="text-lg font-bold text-slate-800">4.2%</span>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="relative">
                      <img src="https://picsum.photos/seed/test2/640/360" className="w-full aspect-video object-cover rounded-lg border-2 border-indigo-500 ring-4 ring-indigo-50" alt="" />
                      <div className="absolute top-2 left-2 bg-indigo-600 text-white text-[10px] font-bold px-2 py-1 rounded shadow-sm">Variant B (Challenger)</div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-bold text-slate-500 uppercase">CTR</span>
                      <span className="text-lg font-bold text-indigo-600">6.8%</span>
                    </div>
                  </div>
                </div>

                <div className="mt-6 pt-6 border-t border-slate-100 flex items-center justify-between">
                  <div className="text-xs font-medium text-slate-600">Statistical Significance: <span className="text-emerald-600 font-bold">94%</span></div>
                  <button className="text-sm font-bold text-indigo-600 hover:underline">Declare Winner</button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white p-6 rounded-xl border border-slate-200">
            <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
              <History size={18} className="text-slate-500" />
              Experiment History
            </h3>
            <div className="space-y-4">
              {[
                { title: 'Title Hook Test', result: 'Win', delta: '+15%', status: 'success' },
                { title: 'Background Color', result: 'Neutral', delta: '0%', status: 'neutral' },
                { title: 'Outline Type', result: 'Loss', delta: '-8%', status: 'fail' }
              ].map((h, i) => (
                <div key={i} className="flex items-center justify-between p-3 border border-slate-100 rounded-lg hover:bg-slate-50 transition-colors">
                  <div className="flex items-center gap-3">
                    {h.status === 'success' ? <CheckCircle2 size={16} className="text-emerald-500" /> : <XCircle size={16} className="text-slate-300" />}
                    <div>
                      <div className="text-xs font-bold text-slate-800">{h.title}</div>
                      <div className="text-[10px] text-slate-500">2 weeks ago</div>
                    </div>
                  </div>
                  <div className={`text-xs font-bold ${h.status === 'success' ? 'text-emerald-600' : 'text-slate-400'}`}>{h.delta}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TestingLab;


import React, { useState } from 'react';
import { OPPORTUNITIES } from '../constants';
import { Plus, GripVertical, Target, Gauge, X } from 'lucide-react';
import { ContentOpportunity } from '../types';

const ContentPlanner: React.FC = () => {
  const [columns] = useState(['Idea', 'Scripted', 'Filmed', 'Edited', 'Scheduled', 'Published']);
  const [opportunities, setOpportunities] = useState<ContentOpportunity[]>(OPPORTUNITIES);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newTopic, setNewTopic] = useState('');

  const handleAddTopic = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTopic.trim()) return;

    const newItem: ContentOpportunity = {
      id: `op-${Date.now()}`,
      topic: newTopic,
      score: Math.floor(Math.random() * 30) + 70,
      demand: 80,
      competition: 50,
      alignment: 90,
      difficulty: 30,
      status: 'Idea'
    };

    setOpportunities([newItem, ...opportunities]);
    setNewTopic('');
    setIsModalOpen(false);
  };

  const moveTask = (id: string, newStatus: any) => {
    setOpportunities(prev => prev.map(op => 
      op.id === id ? { ...op, status: newStatus } : op
    ));
  };

  return (
    <div className="space-y-6 h-full flex flex-col relative">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Content Pipeline</h1>
          <p className="text-slate-500">From strategic gap detection to published reality.</p>
        </div>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium flex items-center gap-2 hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 active:scale-95"
        >
          <Plus size={18} />
          New Topic
        </button>
      </div>

      <div className="flex-1 overflow-x-auto pb-6">
        <div className="flex gap-6 h-full min-h-[600px]">
          {columns.map(col => (
            <div 
              key={col} 
              className="kanban-column flex flex-col gap-4 bg-slate-100/40 p-4 rounded-2xl w-80 border border-slate-200/50"
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                const id = e.dataTransfer.getData('taskId');
                moveTask(id, col as any);
              }}
            >
              <div className="flex items-center justify-between px-2 mb-2">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-700 text-sm tracking-tight">{col}</span>
                  <span className="text-[10px] font-bold bg-white text-slate-500 px-2.5 py-0.5 rounded-full border border-slate-200 shadow-sm">
                    {opportunities.filter(o => o.status === col).length}
                  </span>
                </div>
              </div>

              <div className="space-y-3 flex-1">
                {opportunities.filter(o => o.status === col).map(op => (
                  <div 
                    key={op.id} 
                    draggable
                    onDragStart={(e) => e.dataTransfer.setData('taskId', op.id)}
                    className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:shadow-md hover:border-indigo-300 cursor-grab active:cursor-grabbing group transition-all duration-200 animate-in fade-in slide-in-from-bottom-2"
                  >
                    <div className="flex justify-between items-start mb-3">
                      <div className="text-sm font-bold text-slate-800 leading-tight group-hover:text-indigo-600 transition-colors pr-2">
                        {op.topic}
                      </div>
                      <GripVertical size={16} className="text-slate-300 cursor-move group-hover:text-slate-400 shrink-0" />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-2 mb-4">
                      <div className="flex items-center gap-1.5">
                        <div className="w-1.5 h-1.5 rounded-full bg-emerald-500"></div>
                        <span className="text-[10px] font-bold text-slate-500 uppercase">Score {op.score}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Gauge size={12} className="text-slate-400" />
                        <span className="text-[10px] font-bold text-slate-500 uppercase">Effort {op.difficulty}%</span>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <div className="w-full bg-slate-100 rounded-full h-1">
                        <div 
                          className="bg-indigo-500 h-1 rounded-full transition-all duration-500" 
                          style={{ width: `${op.alignment}%` }}
                        ></div>
                      </div>
                      <div className="flex justify-between items-center text-[10px] font-bold text-slate-400 uppercase">
                        <span>Brand Alignment</span>
                        <span>{op.alignment}%</span>
                      </div>
                    </div>
                  </div>
                ))}

                {opportunities.filter(o => o.status === col).length === 0 && (
                  <div className="border-2 border-dashed border-slate-200 rounded-xl p-8 flex flex-col items-center justify-center opacity-30 group-hover:opacity-50 transition-opacity">
                    <Plus size={24} className="text-slate-400 mb-2" />
                    <span className="text-xs font-medium text-slate-500">Drop here</span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* New Topic Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
              <h3 className="font-bold text-slate-800">New Content Opportunity</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600 transition-colors">
                <X size={20} />
              </button>
            </div>
            <form onSubmit={handleAddTopic} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-1.5">Working Topic Title</label>
                <input 
                  autoFocus
                  type="text" 
                  value={newTopic}
                  onChange={(e) => setNewTopic(e.target.value)}
                  placeholder="e.g. The Future of AI in Construction"
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-none transition-all font-medium"
                />
              </div>
              <div className="pt-2">
                <button 
                  type="submit"
                  className="w-full py-3 bg-indigo-600 text-white rounded-xl font-bold shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all active:scale-[0.98]"
                >
                  Add to Ideas
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ContentPlanner;

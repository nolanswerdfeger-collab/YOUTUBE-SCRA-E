
import React, { useState, useMemo } from 'react';
import { MARKET_VIDEOS, SENTIMENTS } from '../constants';
import { Search, Filter, TrendingUp, MessageSquare, BarChart3 } from 'lucide-react';

const MarketIntelligence: React.FC = () => {
  const [selectedNiche, setSelectedNiche] = useState('AI Automation');
  const [searchQuery, setSearchQuery] = useState('');
  
  const niches = ['AI Automation', 'No-Code', 'SaaS Ops', 'Solopreneurship', 'Tech Productivity'];

  const filteredVideos = useMemo(() => {
    return MARKET_VIDEOS.filter(video => {
      const matchesNiche = video.niche === selectedNiche || selectedNiche === 'All';
      const matchesSearch = video.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                           video.channelName.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesNiche && matchesSearch;
    });
  }, [selectedNiche, searchQuery]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Market Intelligence</h1>
          <p className="text-slate-500">Global trends and niche patterns.</p>
        </div>
        <div className="flex gap-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="Search videos or channels..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-none w-64 transition-all"
            />
          </div>
          <button 
            className="p-2 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors"
            onClick={() => { setSearchQuery(''); setSelectedNiche('AI Automation'); }}
            title="Reset filters"
          >
            <Filter size={18} className="text-slate-500" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Niche Categories Sidebar */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4 px-2">Tracking Niches</h3>
            <div className="space-y-1">
              {niches.map((cat) => (
                <button 
                  key={cat} 
                  onClick={() => setSelectedNiche(cat)}
                  className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                    selectedNiche === cat 
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-100 translate-x-1' 
                      : 'text-slate-600 hover:bg-slate-50 hover:text-indigo-600'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div className="bg-indigo-900 p-6 rounded-xl text-white shadow-lg relative overflow-hidden group">
            <BarChart3 className="absolute -right-4 -bottom-4 opacity-10 group-hover:scale-110 transition-transform duration-500" size={120} />
            <div className="relative z-10">
              <h4 className="text-indigo-200 text-xs font-bold uppercase mb-1">Niche Velocity</h4>
              <div className="text-2xl font-bold">
                {selectedNiche === 'AI Automation' ? '+245%' : selectedNiche === 'No-Code' ? '+112%' : '+45%'}
              </div>
              <p className="text-indigo-300 text-[10px] mt-2 leading-relaxed">
                Mention frequency of topics in <span className="text-white font-bold">{selectedNiche}</span> has spiked significantly in the last 48 hours.
              </p>
            </div>
          </div>
        </div>

        {/* Market Leaderboard */}
        <div className="lg:col-span-3 space-y-6">
          <div>
            <div className="flex items-center justify-between mb-4 px-1">
              <h3 className="font-bold text-slate-800 flex items-center gap-2">
                <TrendingUp size={18} className="text-indigo-600" />
                Performance Leaderboard: {selectedNiche}
              </h3>
              <span className="text-[10px] font-bold text-slate-400 uppercase">{filteredVideos.length} Videos found</span>
            </div>
            
            {filteredVideos.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {filteredVideos.map(video => (
                  <div key={video.id} className="group bg-white rounded-xl border border-slate-200 overflow-hidden hover:border-indigo-400 hover:shadow-lg transition-all duration-300 shadow-sm">
                    <div className="relative aspect-video">
                      <img src={video.thumbnailUrl} className="w-full h-full object-cover" alt="" />
                      <div className="absolute inset-0 bg-indigo-900/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-1 backdrop-blur-[2px]">
                        <div className="text-white text-xl font-black">{(video.metrics.views / 1000).toFixed(1)}K</div>
                        <div className="text-[10px] text-indigo-100 uppercase font-bold tracking-wider">Views Today</div>
                      </div>
                      <div className="absolute bottom-2 right-2 bg-black/70 text-white text-[10px] px-1.5 py-0.5 rounded font-mono">
                        {video.engagementRate}% ENG
                      </div>
                    </div>
                    <div className="p-4">
                      <div className="text-sm font-bold text-slate-800 mb-1 line-clamp-1 group-hover:text-indigo-600 transition-colors">{video.title}</div>
                      <div className="flex items-center justify-between text-[10px] text-slate-500 uppercase font-bold">
                        <span>{video.channelName}</span>
                        <span className="text-indigo-500 font-black">High Velocity</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-white border border-dashed border-slate-200 rounded-2xl p-12 text-center">
                <div className="text-slate-400 mb-2">No videos matching filters</div>
                <button 
                  onClick={() => { setSearchQuery(''); setSelectedNiche('AI Automation'); }}
                  className="text-indigo-600 text-sm font-bold hover:underline"
                >
                  Clear all filters
                </button>
              </div>
            )}
          </div>

          {/* Sentiment Analysis Section */}
          <div>
            <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
              <MessageSquare size={18} className="text-indigo-600" />
              Audience Sentiment Insights
            </h3>
            <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm">
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead className="bg-slate-50 border-b border-slate-200">
                    <tr>
                      <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase">Category</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase">Key Phrase Patterns</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase">Trend Intensity</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {SENTIMENTS.map(s => (
                      <tr key={s.id} className="hover:bg-indigo-50/30 transition-colors group">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2.5 py-1 rounded text-[10px] font-bold uppercase tracking-tight shadow-sm ${
                            s.category === 'Request' ? 'bg-indigo-100 text-indigo-700 border border-indigo-200' :
                            s.category === 'Pain Point' ? 'bg-rose-100 text-rose-700 border border-rose-200' :
                            'bg-emerald-100 text-emerald-700 border border-emerald-200'
                          }`}>
                            {s.category}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex flex-wrap gap-1.5">
                            {s.phrases.map(p => (
                              <span key={p} className="bg-slate-100 text-slate-600 text-[10px] px-2 py-0.5 rounded-md font-semibold border border-slate-200 group-hover:bg-white transition-colors">{p}</span>
                            ))}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="flex-1 bg-slate-100 rounded-full h-1.5 min-w-[80px]">
                              <div className="bg-indigo-500 h-1.5 rounded-full transition-all duration-1000" style={{ width: `${Math.floor(Math.random() * 40) + 60}%` }}></div>
                            </div>
                            <span className="text-[10px] font-bold text-slate-400">HIGH</span>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MarketIntelligence;

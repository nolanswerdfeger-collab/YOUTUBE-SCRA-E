
import React from 'react';
import { 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';
import MetricCard from '../components/MetricCard';
import { MY_VIDEOS, MARKET_VIDEOS, OPPORTUNITIES } from '../constants';
import { Flame, Bell, CheckCircle2, TrendingUp, Zap } from 'lucide-react';

const data = [
  { name: 'Mon', views: 4000 },
  { name: 'Tue', views: 3000 },
  { name: 'Wed', views: 2000 },
  { name: 'Thu', views: 2780 },
  { name: 'Fri', views: 1890 },
  { name: 'Sat', views: 2390 },
  { name: 'Sun', views: 3490 },
];

const CommandCenter: React.FC = () => {
  const outliers = MY_VIDEOS.filter(v => v.isOutlier);

  return (
    <div className="space-y-8 pb-12 animate-in fade-in duration-500">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight">Command Center</h1>
          <p className="text-slate-500 font-medium">Strategic overview of channel health & market trends.</p>
        </div>
        <div className="flex gap-3">
          <button className="px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-600 flex items-center gap-2 hover:bg-slate-50 transition-all shadow-sm">
            <Bell size={18} className="text-slate-400" />
            Alerts
          </button>
          <button className="px-5 py-2.5 bg-indigo-600 text-white rounded-xl text-sm font-black hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 active:scale-95">
            Sync Analytics
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard label="7-Day Reach" value="48.5K" delta={12.4} />
        <MetricCard label="Engagement" value="12.2K" delta={8.2} />
        <MetricCard label="Click Through" value="7.2" suffix="%" delta={-1.5} />
        <MetricCard label="Conversion" value="1.4K" delta={25.1} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Main Chart */}
        <div className="lg:col-span-8 bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center text-indigo-600">
                <TrendingUp size={20} />
              </div>
              <h3 className="font-black text-slate-800 tracking-tight">Growth Velocity</h3>
            </div>
            <select className="bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold text-slate-500 px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-indigo-500/20">
              <option>Last 7 Days</option>
              <option>Last 30 Days</option>
            </select>
          </div>
          <div className="h-[320px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <defs>
                  <linearGradient id="colorViews" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.15}/>
                    <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 12, fontWeight: 600, fill: '#94a3b8'}} dy={15} />
                <YAxis axisLine={false} tickLine={false} tick={{fontSize: 12, fontWeight: 600, fill: '#94a3b8'}} />
                <Tooltip 
                  contentStyle={{borderRadius: '16px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)', padding: '12px'}}
                  cursor={{stroke: '#4f46e5', strokeWidth: 2, strokeDasharray: '5 5'}}
                />
                <Area type="monotone" dataKey="views" stroke="#4f46e5" strokeWidth={4} fillOpacity={1} fill="url(#colorViews)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Pulse Sidebar */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex flex-col h-full">
            <h3 className="font-black text-slate-800 mb-6 flex items-center gap-2">
              <Flame size={20} className="text-orange-500" />
              Market Pulse
            </h3>
            <div className="space-y-5 flex-1">
              {MARKET_VIDEOS.map(video => (
                <div key={video.id} className="group cursor-pointer flex gap-4 items-center">
                  <div className="relative shrink-0 overflow-hidden rounded-xl border border-slate-100 shadow-sm w-20 aspect-video">
                    <img src={video.thumbnailUrl} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" alt="" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-black text-slate-800 truncate group-hover:text-indigo-600 transition-colors leading-tight mb-0.5">{video.title}</div>
                    <div className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">{video.channelName} • {(video.metrics.views / 1000).toFixed(0)}K views</div>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-8 pt-6 border-t border-slate-50">
              <h3 className="font-black text-slate-800 mb-4 flex items-center gap-2">
                <CheckCircle2 size={18} className="text-emerald-500" />
                High Impact Tasks
              </h3>
              <ul className="space-y-3">
                {OPPORTUNITIES.slice(0, 2).map(op => (
                  <li key={op.id} className="flex items-center gap-3 p-2 bg-slate-50 rounded-xl group hover:bg-indigo-50 transition-all cursor-pointer">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-black text-xs ${op.score > 90 ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-500'}`}>
                      {op.score}
                    </div>
                    <span className="flex-1 text-xs font-bold text-slate-600 group-hover:text-indigo-700 truncate">{op.topic}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Outliers Feed */}
      <div>
        <div className="flex items-center justify-between mb-6">
          <h3 className="font-black text-slate-800 text-xl tracking-tight flex items-center gap-2">
            <Zap size={20} className="text-indigo-600" />
            Detected Performance Spikes
          </h3>
          <button className="text-xs font-bold text-indigo-600 hover:underline">View All Analysis</button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {outliers.map(video => (
            <div key={video.id} className="group bg-white rounded-[2rem] border border-slate-200 overflow-hidden shadow-sm hover:shadow-xl hover:border-indigo-300 transition-all duration-300">
              <div className="relative">
                <img src={video.thumbnailUrl} className="w-full aspect-video object-cover" alt="" />
                <div className="absolute top-4 right-4 bg-indigo-600 text-white text-[10px] font-black px-3 py-1.5 rounded-full shadow-lg border border-white/20">
                  {video.outlierDelta}x OUTLIER
                </div>
              </div>
              <div className="p-6">
                <div className="text-sm font-black text-slate-900 mb-4 line-clamp-2 leading-tight group-hover:text-indigo-600 transition-colors">
                  {video.title}
                </div>
                <div className="flex justify-between items-center bg-slate-50 p-3 rounded-2xl">
                  <div className="text-center">
                    <div className="text-[10px] font-black text-slate-400 uppercase">Views</div>
                    <div className="text-sm font-black text-slate-800">{(video.metrics.views / 1000).toFixed(1)}K</div>
                  </div>
                  <div className="w-px h-6 bg-slate-200"></div>
                  <div className="text-center">
                    <div className="text-[10px] font-black text-slate-400 uppercase">Avg Views</div>
                    <div className="text-sm font-black text-slate-500">{(video.channelAvgViews || 15000) / 1000}K</div>
                  </div>
                  <div className="w-px h-6 bg-slate-200"></div>
                  <div className="text-center">
                    <div className="text-[10px] font-black text-slate-400 uppercase">Lift</div>
                    <div className="text-sm font-black text-emerald-600">+{((video.metrics.views / (video.channelAvgViews || 15000) - 1) * 100).toFixed(0)}%</div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CommandCenter;


import React, { useState } from 'react';
import { 
  Link as LinkIcon, 
  Plus, 
  TrendingUp, 
  Save, 
  Zap, 
  Loader2,
  Trash2,
  ExternalLink,
  Database,
  Search,
  ArrowRight
} from 'lucide-react';
import { analyzeVideoUrl } from '../services/geminiService';
import { CHANNEL_AVG_VIEWS, OPPORTUNITIES } from '../constants';
import { ContentOpportunity } from '../types';

const IdeasVault: React.FC = () => {
  const [url, setUrl] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [vault, setVault] = useState<ContentOpportunity[]>(OPPORTUNITIES);

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.includes('youtube.com') && !url.includes('youtu.be')) return;
    
    setAnalyzing(true);
    setResult(null);
    try {
      const data = await analyzeVideoUrl(url);
      const multiple = data.estimatedViews / CHANNEL_AVG_VIEWS;
      setResult({ ...data, multiple });
    } catch (err) {
      console.error(err);
      // Fallback for demo if API fails
      setResult({
        title: "AI Strategy: How to Build a $100k/mo Automation Agency",
        thumbnailUrl: "https://images.unsplash.com/photo-1664575196412-ed801e83f427?q=80&w=800&auto=format&fit=crop",
        estimatedViews: 48000,
        multiple: 3.2
      });
    } finally {
      setAnalyzing(false);
    }
  };

  const handleSave = () => {
    if (!result) return;
    const newIdea: ContentOpportunity = {
      id: `vault-${Date.now()}`,
      topic: result.title,
      score: Math.floor(result.multiple * 20) + 50,
      demand: 80,
      competition: 40,
      alignment: 95,
      difficulty: 30,
      status: 'Idea',
      thumbnailUrl: result.thumbnailUrl,
      performanceMultiple: result.multiple
    };
    setVault([newIdea, ...vault]);
    setResult(null);
    setUrl('');
  };

  const removeIdea = (id: string) => {
    setVault(vault.filter(i => i.id !== id));
  };

  const getHeatColor = (multiple: number) => {
    if (multiple >= 5) return 'text-rose-600 bg-rose-50 border-rose-200 ring-rose-500 shadow-rose-100';
    if (multiple >= 2.5) return 'text-indigo-600 bg-indigo-50 border-indigo-200 ring-indigo-500 shadow-indigo-100';
    if (multiple >= 1.5) return 'text-emerald-600 bg-emerald-50 border-emerald-200 ring-emerald-500 shadow-emerald-100';
    return 'text-slate-500 bg-slate-50 border-slate-200 ring-slate-400 shadow-slate-100';
  };

  return (
    <div className="space-y-12 animate-in fade-in slide-in-from-bottom-6 duration-700 pb-20">
      <div className="max-w-3xl mx-auto text-center space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-50 text-indigo-600 rounded-full text-[10px] font-black uppercase tracking-widest mb-2 border border-indigo-100">
          <TrendingUp size={12} />
          Strategic Content Detection
        </div>
        <h1 className="text-5xl font-black text-slate-900 tracking-tight leading-[1.1]">The Ideas Vault</h1>
        <p className="text-slate-500 font-medium text-lg">Input any YouTube URL to calculate performance lift and save high-velocity topics to your production roadmap.</p>
        
        <form onSubmit={handleAnalyze} className="relative mt-12 group max-w-2xl mx-auto">
          <div className="absolute -inset-1 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-[2rem] opacity-20 blur-2xl group-focus-within:opacity-40 transition-opacity"></div>
          <div className="relative flex gap-2 p-2 bg-white border border-slate-200 rounded-[1.8rem] shadow-2xl shadow-indigo-100/50">
            <div className="flex-1 flex items-center px-5 gap-4">
              <LinkIcon size={20} className="text-slate-400" />
              <input 
                type="text" 
                placeholder="Paste YouTube Video URL..." 
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                className="w-full bg-transparent border-none focus:ring-0 text-base font-bold text-slate-800 placeholder:text-slate-300 placeholder:font-medium"
              />
            </div>
            <button 
              disabled={analyzing || !url}
              className="px-8 py-3.5 bg-indigo-600 text-white rounded-2xl text-sm font-black flex items-center gap-2 hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-xl shadow-indigo-200 active:scale-95"
            >
              {analyzing ? <Loader2 size={18} className="animate-spin" /> : <Zap size={18} />}
              {analyzing ? 'Detecting...' : 'Analyze Lift'}
            </button>
          </div>
        </form>
      </div>

      {result && (
        <div className="max-w-5xl mx-auto bg-white rounded-[2.5rem] border border-slate-200 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-500 p-2">
          <div className="flex flex-col md:flex-row bg-slate-50/50 rounded-[2.2rem]">
            <div className="w-full md:w-1/2 p-3">
              <div className="relative group overflow-hidden rounded-[1.8rem] shadow-lg">
                <img src={result.thumbnailUrl} className="w-full aspect-video object-cover group-hover:scale-105 transition-transform duration-1000" alt="" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                <div className="absolute bottom-6 left-6 text-white">
                  <div className="text-[10px] font-black uppercase tracking-widest opacity-70 mb-1">Visual Architecture</div>
                  <div className="text-lg font-bold">Market Anomaly Detected</div>
                </div>
              </div>
            </div>
            <div className="flex-1 p-10 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 mb-4">
                  <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Growth Analytics Report</span>
                </div>
                <h3 className="text-2xl font-black text-slate-900 leading-tight mb-8">{result.title}</h3>
                
                <div className="flex items-center gap-10">
                  <div>
                    <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Estimated Potential</div>
                    <div className="text-3xl font-black text-slate-800 tracking-tighter">{(result.estimatedViews / 1000).toFixed(0)}K <span className="text-lg text-slate-300">views</span></div>
                  </div>
                  <div className="w-px h-12 bg-slate-200"></div>
                  <div>
                    <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Outlier Factor</div>
                    <div className="flex items-end gap-2">
                      <div className={`text-4xl font-black leading-none ${result.multiple > 1.5 ? 'text-indigo-600' : 'text-slate-600'}`}>
                        {result.multiple.toFixed(1)}x
                      </div>
                      <div className="flex flex-col">
                        <span className="text-[10px] font-black text-indigo-500 uppercase leading-none mb-1">vs Avg</span>
                        <div className="w-12 h-1 bg-slate-100 rounded-full">
                          <div className="bg-indigo-500 h-1 rounded-full" style={{ width: `${Math.min(result.multiple * 20, 100)}%` }}></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-12 flex gap-4">
                <button 
                  onClick={handleSave}
                  className="flex-1 py-4 bg-indigo-600 text-white rounded-2xl font-black flex items-center justify-center gap-3 hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100 group"
                >
                  <Save size={20} />
                  Save framework to Dashboard
                  <ArrowRight size={18} className="opacity-0 group-hover:opacity-100 group-hover:translate-x-1 transition-all" />
                </button>
                <button 
                  onClick={() => setResult(null)}
                  className="px-8 py-4 border border-slate-200 text-slate-500 rounded-2xl font-black hover:bg-slate-50 transition-all"
                >
                  Discard
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="space-y-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-white rounded-2xl border border-slate-200 flex items-center justify-center text-indigo-600 shadow-sm">
              <Database size={24} />
            </div>
            <div>
              <h2 className="text-3xl font-black text-slate-900 tracking-tight">Saved Frameworks</h2>
              <p className="text-slate-400 text-sm font-medium">Your curated database of market-tested content ideas.</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
              <input type="text" placeholder="Search ideas..." className="pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold focus:ring-2 focus:ring-indigo-500/20 focus:outline-none w-48" />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {vault.map((idea) => (
            <div key={idea.id} className="group bg-white rounded-[2rem] border border-slate-200 shadow-sm hover:shadow-2xl hover:border-indigo-200 transition-all duration-500 overflow-hidden flex flex-col hover:-translate-y-1">
              <div className="relative aspect-video overflow-hidden">
                <img 
                  src={idea.thumbnailUrl || 'https://images.unsplash.com/photo-1593642532400-2682810df593?auto=format&fit=crop&q=80&w=800'} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" 
                  alt="" 
                />
                {idea.performanceMultiple && (
                  <div className={`absolute top-4 right-4 px-3 py-1.5 rounded-full border font-black text-[10px] tracking-tight shadow-lg flex items-center gap-2 backdrop-blur-md ${getHeatColor(idea.performanceMultiple)}`}>
                    <Zap size={12} />
                    {idea.performanceMultiple.toFixed(1)}x LIFT
                  </div>
                )}
                <div className="absolute inset-0 bg-indigo-900/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-[2px]">
                   <button className="px-6 py-2.5 bg-white rounded-full text-indigo-600 font-black text-xs shadow-xl hover:scale-105 active:scale-95 transition-all flex items-center gap-2">
                      <ExternalLink size={14} />
                      View Analytics
                   </button>
                </div>
              </div>
              <div className="p-8 flex-1 flex flex-col">
                <h4 className="font-black text-slate-800 text-lg leading-tight line-clamp-2 mb-6 flex-1 group-hover:text-indigo-600 transition-colors">{idea.topic}</h4>
                
                <div className="flex items-center justify-between pt-6 border-t border-slate-50">
                  <div className="flex items-center gap-6">
                    <div className="text-center">
                      <div className="text-[10px] font-black text-slate-400 uppercase tracking-tighter mb-1">Score</div>
                      <div className="text-lg font-black text-indigo-600 leading-none">{idea.score}</div>
                    </div>
                    <div className="text-center">
                      <div className="text-[10px] font-black text-slate-400 uppercase tracking-tighter mb-1">Match</div>
                      <div className="text-lg font-black text-slate-800 leading-none">{idea.alignment}%</div>
                    </div>
                  </div>
                  <button 
                    onClick={() => removeIdea(idea.id)}
                    className="w-10 h-10 flex items-center justify-center text-slate-300 hover:text-rose-500 hover:bg-rose-50 rounded-xl transition-all"
                    title="Delete Idea"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              </div>
            </div>
          ))}

          {vault.length === 0 && (
            <div className="col-span-full py-24 text-center space-y-6 bg-slate-50/50 rounded-[3rem] border border-dashed border-slate-200">
              <div className="w-20 h-20 bg-white rounded-3xl border border-slate-100 flex items-center justify-center mx-auto text-slate-300 shadow-sm">
                <Database size={40} />
              </div>
              <div>
                <h3 className="text-xl font-black text-slate-800 tracking-tight">Your vault is currently empty</h3>
                <p className="text-slate-400 font-medium max-w-xs mx-auto">Analyze market outliers to build your database of winning frameworks.</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default IdeasVault;


export interface VideoMetric {
  views: number;
  watchTime: number;
  ctr: number;
  avgViewDuration: number;
  subs: number;
}

export interface YouTubeVideo {
  id: string;
  title: string;
  thumbnailUrl: string;
  publishDate: string;
  metrics: VideoMetric;
  isOutlier?: boolean;
  outlierDelta?: number;
  category: string;
  channelAvgViews?: number;
}

export interface MarketVideo extends YouTubeVideo {
  channelName: string;
  channelSubs: string;
  niche: string;
  engagementRate: number;
}

export interface CommentSentiment {
  id: string;
  text: string;
  category: 'Positive' | 'Pain Point' | 'Request' | 'Competitive';
  phrases: string[];
}

export interface ContentOpportunity {
  id: string;
  topic: string;
  score: number;
  demand: number;
  competition: number;
  alignment: number;
  difficulty: number;
  status: 'Idea' | 'Scripted' | 'Filmed' | 'Edited' | 'Scheduled' | 'Published';
  thumbnailUrl?: string;
  performanceMultiple?: number;
}

export type ViewType = 'command' | 'outliers' | 'market' | 'planner' | 'lab' | 'vault' | 'settings';

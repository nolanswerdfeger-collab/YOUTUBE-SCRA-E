
import { GoogleGenAI, Type } from "@google/genai";

// Standardizing initialization to use process.env.API_KEY directly within each service call
export const analyzeOutlier = async (title: string, metrics: any) => {
  // Always use process.env.API_KEY directly
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `You are a world-class YouTube growth strategist. Analyze why this specific video is a massive outlier (performing significantly above the channel average).

Title: "${title}"
Performance Metrics: ${JSON.stringify(metrics)}

Provide a highly structured, strategic analysis in Markdown. Use these exact sections:
### ⚡ The Hook Architecture
Explain the psychological triggers in the title and thumbnail concept. Why did they click?

### 🎯 Audience Persona
Who is the specific avatar this video attracted that the channel usually doesn't reach?

### 🚀 Scaling & Replication
Give 3 concrete, actionable steps to replicate this success in future videos.

Keep it punchy, professional, and data-driven. Use bold text and bullet points.`,
    config: {
      thinkingConfig: { thinkingBudget: 0 }
    }
  });
  return response.text;
};

export const analyzeVideoUrl = async (url: string) => {
  // Always use process.env.API_KEY directly
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Analyze the following YouTube URL: ${url}. 
    Since you can't access live data, generate a realistic Title, Thumbnail URL (use a high-quality Unsplash tech image), and estimated view count for an 'AI Automation' niche channel. 
    Format the response as JSON.`,
    config: {
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          thumbnailUrl: { type: Type.STRING },
          estimatedViews: { type: Type.NUMBER },
          niche: { type: Type.STRING }
        },
        required: ['title', 'thumbnailUrl', 'estimatedViews']
      }
    }
  });
  return JSON.parse(response.text || '{}');
};

export const generateOpportunityScore = async (topic: string) => {
  // Always use process.env.API_KEY directly
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Calculate an opportunity score for the topic: "${topic}" in the YouTube AI Automation niche. Return JSON.`,
    config: {
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          score: { type: Type.NUMBER },
          reasoning: { type: Type.STRING },
          targetKeywords: { type: Type.ARRAY, items: { type: Type.STRING } }
        },
        required: ['score', 'reasoning']
      }
    }
  });
  return JSON.parse(response.text || '{}');
};

export const classifySentiments = async (comments: string[]) => {
  // Always use process.env.API_KEY directly
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Classify these YouTube comments into: Positive, Pain Point, Request, Competitive. 
    Comments: ${comments.join(' | ')}`,
    config: {
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            text: { type: Type.STRING },
            category: { type: Type.STRING },
            summary: { type: Type.STRING }
          }
        }
      }
    }
  });
  return JSON.parse(response.text || '[]');
};

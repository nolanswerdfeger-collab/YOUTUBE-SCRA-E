
import React from 'react';
import { 
  LayoutDashboard, 
  TrendingUp, 
  Globe, 
  PenTool, 
  FlaskConical, 
  Settings,
  ChevronRight,
  Database
} from 'lucide-react';
import { ViewType } from '../types';

interface SidebarProps {
  currentView: ViewType;
  onViewChange: (view: ViewType) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, onViewChange }) => {
  const menuItems = [
    { id: 'command', icon: LayoutDashboard, label: 'Command Center' },
    { id: 'outliers', icon: TrendingUp, label: 'Outlier Deep Dive' },
    { id: 'market', icon: Globe, label: 'Market Intelligence' },
    { id: 'vault', icon: Database, label: 'Ideas Vault' },
    { id: 'planner', icon: PenTool, label: 'Content Planner' },
    { id: 'lab', icon: FlaskConical, label: 'Testing Lab' },
  ];

  return (
    <div className="w-64 h-full bg-white border-r border-slate-200 flex flex-col">
      <div className="p-6 flex items-center gap-3">
        <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
          <span className="text-white font-bold text-sm tracking-tighter">YT</span>
        </div>
        <span className="font-bold text-slate-800 tracking-tight">Intelligence</span>
      </div>

      <nav className="flex-1 px-4 py-4 space-y-1 overflow-y-auto">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onViewChange(item.id as ViewType)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-all duration-200 group ${
                isActive 
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-100' 
                  : 'text-slate-500 hover:bg-slate-50 hover:text-slate-800'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon size={18} className={isActive ? 'text-white' : 'text-slate-400 group-hover:text-slate-600'} />
                <span className="font-bold text-sm">{item.label}</span>
              </div>
              {isActive && <ChevronRight size={14} className="opacity-60" />}
            </button>
          );
        })}
      </nav>

      <div className="p-4 border-t border-slate-100">
        <button 
          onClick={() => onViewChange('settings')}
          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-bold transition-all ${
            currentView === 'settings'
              ? 'bg-slate-100 text-slate-900 shadow-sm'
              : 'text-slate-500 hover:bg-slate-50 hover:text-slate-800'
          }`}
        >
          <Settings size={18} className={currentView === 'settings' ? 'text-slate-900' : 'text-slate-400'} />
          <span>Settings</span>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;

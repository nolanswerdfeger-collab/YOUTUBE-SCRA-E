
import React from 'react';
import { ArrowUpRight, ArrowDownRight } from 'lucide-react';

interface MetricCardProps {
  label: string;
  value: string | number;
  delta?: number;
  suffix?: string;
}

const MetricCard: React.FC<MetricCardProps> = ({ label, value, delta, suffix }) => {
  return (
    <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
      <div className="text-slate-500 text-sm font-medium mb-1">{label}</div>
      <div className="flex items-end gap-2">
        <span className="text-2xl font-bold text-slate-900">{value}{suffix}</span>
        {delta !== undefined && (
          <div className={`flex items-center text-xs font-bold mb-1 ${delta >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
            {delta >= 0 ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
            {Math.abs(delta)}%
          </div>
        )}
      </div>
    </div>
  );
};

export default MetricCard;

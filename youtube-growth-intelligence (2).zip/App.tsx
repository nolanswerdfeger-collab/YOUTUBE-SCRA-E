
import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import CommandCenter from './views/CommandCenter';
import OutlierDeepDive from './views/OutlierDeepDive';
import MarketIntelligence from './views/MarketIntelligence';
import ContentPlanner from './views/ContentPlanner';
import TestingLab from './views/TestingLab';
import IdeasVault from './views/IdeasVault';
import SettingsView from './views/SettingsView';
import { ViewType } from './types';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewType>('command');

  const renderView = () => {
    switch (currentView) {
      case 'command': return <CommandCenter />;
      case 'outliers': return <OutlierDeepDive />;
      case 'market': return <MarketIntelligence />;
      case 'planner': return <ContentPlanner />;
      case 'lab': return <TestingLab />;
      case 'vault': return <IdeasVault />;
      case 'settings': return <SettingsView />;
      default: return <CommandCenter />;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50">
      <Sidebar currentView={currentView} onViewChange={setCurrentView} />
      
      <main className="flex-1 overflow-y-auto relative">
        <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-md border-b border-slate-200 px-8 py-4 flex justify-between items-center">
          <div className="flex items-center gap-4">
            <div className="px-3 py-1 bg-slate-100 rounded-full text-xs font-bold text-slate-500 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              Strategic Sync Active
            </div>
            <div className="text-xs font-medium text-slate-400">Market Intelligence Engine v1.2</div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="text-sm font-bold text-slate-800 leading-none uppercase tracking-tighter">Content Command</div>
              <div className="text-[10px] font-medium text-slate-500">Analytics Session: Online</div>
            </div>
            <div className="w-10 h-10 rounded-2xl bg-indigo-600 flex items-center justify-center text-white font-black text-xs">
              DT
            </div>
          </div>
        </header>

        <div className="p-8 max-w-7xl mx-auto">
          {renderView()}
        </div>
      </main>
    </div>
  );
};

export default App;

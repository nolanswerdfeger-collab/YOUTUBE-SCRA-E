
import { YouTubeVideo, MarketVideo, ContentOpportunity, CommentSentiment } from './types';

export const CHANNEL_AVG_VIEWS = 15000;

// High quality reliable tech/AI stock images
const IMAGES = {
  ai_saas: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?q=80&w=800&auto=format&fit=crop',
  no_code: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=800&auto=format&fit=crop',
  workflow: 'https://images.unsplash.com/photo-1518770660439-4636190af475?q=80&w=800&auto=format&fit=crop',
  gemini: 'https://images.unsplash.com/photo-1620712943543-bcc4628c9757?q=80&w=800&auto=format&fit=crop',
  zapier: 'https://images.unsplash.com/photo-1551288049-bbbda536339a?q=80&w=800&auto=format&fit=crop',
  automation: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?q=80&w=800&auto=format&fit=crop',
};

export const MY_VIDEOS: YouTubeVideo[] = [
  {
    id: 'v1',
    title: 'Building an AI Automation SaaS in 24 Hours',
    thumbnailUrl: IMAGES.ai_saas,
    publishDate: '2023-10-15',
    category: 'AI Automation',
    metrics: { views: 45000, watchTime: 8200, ctr: 8.5, avgViewDuration: 420, subs: 1200 },
    isOutlier: true,
    outlierDelta: 2.5,
    channelAvgViews: CHANNEL_AVG_VIEWS
  },
  {
    id: 'v2',
    title: 'Why Most No-Code Agencies Fail',
    thumbnailUrl: IMAGES.no_code,
    publishDate: '2023-11-02',
    category: 'No-Code',
    metrics: { views: 12000, watchTime: 2100, ctr: 4.2, avgViewDuration: 280, subs: 340 },
    channelAvgViews: CHANNEL_AVG_VIEWS
  },
  {
    id: 'v3',
    title: 'The Secret to Scale: Workflow Automation',
    thumbnailUrl: IMAGES.workflow,
    publishDate: '2023-11-10',
    category: 'Workflow Automation',
    metrics: { views: 28000, watchTime: 5400, ctr: 7.1, avgViewDuration: 390, subs: 890 },
    isOutlier: true,
    outlierDelta: 1.8,
    channelAvgViews: CHANNEL_AVG_VIEWS
  }
];

export const MARKET_VIDEOS: MarketVideo[] = [
  {
    id: 'm1',
    channelName: 'AI Explainer',
    channelSubs: '500K',
    title: 'Gemini 3 Pro: Everything You Need to Know',
    thumbnailUrl: IMAGES.gemini,
    publishDate: '2023-12-01',
    category: 'AI News',
    niche: 'AI Automation',
    engagementRate: 9.2,
    metrics: { views: 120000, watchTime: 15000, ctr: 12.5, avgViewDuration: 600, subs: 4500 }
  },
  {
    id: 'm2',
    channelName: 'TechFlow',
    channelSubs: '200K',
    title: 'Stop Using Zapier. Do This Instead.',
    thumbnailUrl: IMAGES.zapier,
    publishDate: '2023-12-03',
    category: 'Tools',
    niche: 'Workflow Automation',
    engagementRate: 11.4,
    metrics: { views: 85000, watchTime: 9200, ctr: 10.1, avgViewDuration: 450, subs: 2100 }
  },
  {
    id: 'm3',
    channelName: 'AutoGuru',
    channelSubs: '150K',
    title: '5 AI Automations That Save 20 Hours Weekly',
    thumbnailUrl: IMAGES.automation,
    publishDate: '2023-12-05',
    category: 'Strategy',
    niche: 'AI Automation',
    engagementRate: 8.7,
    metrics: { views: 64000, watchTime: 7200, ctr: 9.4, avgViewDuration: 510, subs: 1800 }
  }
];

export const OPPORTUNITIES: ContentOpportunity[] = [
  { id: 'op1', topic: 'AI for Small Business Operations', score: 92, demand: 85, competition: 30, alignment: 95, difficulty: 40, status: 'Idea', performanceMultiple: 3.2, thumbnailUrl: IMAGES.automation },
  { id: 'op2', topic: 'OpenAI DevDay React for Beginners', score: 88, demand: 90, competition: 60, alignment: 80, difficulty: 20, status: 'Scripted', performanceMultiple: 1.5, thumbnailUrl: IMAGES.ai_saas },
  { id: 'op3', topic: 'The Future of No-Code Agencies', score: 75, demand: 70, competition: 40, alignment: 90, difficulty: 50, status: 'Idea', performanceMultiple: 0.8, thumbnailUrl: IMAGES.no_code },
];

export const SENTIMENTS: CommentSentiment[] = [
  { id: 's1', text: "Can you show how to integrate this with Google Calendar?", category: 'Request', phrases: ['Google Calendar', 'Integrate'] },
  { id: 's2', text: "The audio quality is amazing in this one!", category: 'Positive', phrases: ['Audio quality'] },
  { id: 's3', text: "Setting up the API keys is so confusing for beginners.", category: 'Pain Point', phrases: ['API keys', 'Confusing'] },
];
